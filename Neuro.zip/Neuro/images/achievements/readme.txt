Here you can drop your achievement icons.
It must be named the same as its "save" variable.

If you add "-pixel" at the end of the image name, it will turn off antialiasing for that icon.
Example: "week6_nomiss-pixel.png"