--BUDYN--
function onUpdate(elapsed)
	noteTweenAlpha("Note2", 2, 0, 1, ".cubeInOut")
        noteTweenAlpha("Note0", 0, 0, 1, ".cubeInOut")
	noteTweenAlpha("Note1", 1, 0, 1, ".cubeInOut")
        noteTweenAlpha("Note3", 3, 0, 1, ".cubeInOut")
end